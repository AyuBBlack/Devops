﻿namespace SqlBundle.Models
{
    public class History
    {
        public int Id { get; set; }
        public string Date { get; set; }
        public string Parametrs { get; set; }
        public string Results { get; set; }
    }

}
